	.file	"task08_billing.c"
	.text
	.globl	compute_bill
	.type	compute_bill, @function
compute_bill:
.LFB0:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	movl	%edi, -20(%rbp)
	movq	$5000, -8(%rbp)
	cmpl	$200, -20(%rbp)
	jle	.L2
	movl	-20(%rbp), %eax
	subl	$200, %eax
	cltq
	imulq	$450, %rax, %rax
	addq	%rax, -8(%rbp)
.L2:
	cmpl	$100, -20(%rbp)
	jle	.L3
	movl	-20(%rbp), %eax
	movl	$200, %edx
	cmpl	%edx, %eax
	cmovg	%edx, %eax
	movl	%eax, -12(%rbp)
	movl	-12(%rbp), %eax
	subl	$100, %eax
	cltq
	imulq	$225, %rax, %rax
	addq	%rax, -8(%rbp)
.L3:
	movq	-8(%rbp), %rax
	popq	%rbp
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE0:
	.size	compute_bill, .-compute_bill
	.section	.rodata
	.align 8
.LC0:
	.string	"%3d units -> Rs %ld.%02ld   (rupees to paise macro: %ld)\n"
	.text
	.globl	main
	.type	main, @function
main:
.LFB1:
	.cfi_startproc
	endbr64
	pushq	%rbp
	.cfi_def_cfa_offset 16
	.cfi_offset 6, -16
	movq	%rsp, %rbp
	.cfi_def_cfa_register 6
	subq	$48, %rsp
	movq	%fs:40, %rax
	movq	%rax, -8(%rbp)
	xorl	%eax, %eax
	movl	$0, -20(%rbp)
	movl	$150, -16(%rbp)
	movl	$350, -12(%rbp)
	movl	$0, -36(%rbp)
	jmp	.L6
.L7:
	movl	-36(%rbp), %eax
	cltq
	movl	-20(%rbp,%rax,4), %eax
	movl	%eax, %edi
	call	compute_bill
	movq	%rax, -32(%rbp)
	movq	-32(%rbp), %rcx
	movabsq	$-6640827866535438581, %rdx
	movq	%rcx, %rax
	imulq	%rdx
	leaq	(%rdx,%rcx), %rax
	sarq	$6, %rax
	movq	%rax, %rdx
	movq	%rcx, %rax
	sarq	$63, %rax
	subq	%rax, %rdx
	movq	%rdx, %rax
	salq	$2, %rax
	addq	%rdx, %rax
	leaq	0(,%rax,4), %rdx
	addq	%rdx, %rax
	salq	$2, %rax
	movq	%rax, %rdi
	movq	-32(%rbp), %rcx
	movabsq	$-6640827866535438581, %rdx
	movq	%rcx, %rax
	imulq	%rdx
	leaq	(%rdx,%rcx), %rax
	sarq	$6, %rax
	movq	%rax, %rdx
	movq	%rcx, %rax
	sarq	$63, %rax
	movq	%rdx, %rsi
	subq	%rax, %rsi
	movq	%rsi, %rax
	salq	$2, %rax
	addq	%rsi, %rax
	leaq	0(,%rax,4), %rdx
	addq	%rdx, %rax
	salq	$2, %rax
	movq	%rcx, %rsi
	subq	%rax, %rsi
	movq	-32(%rbp), %rcx
	movabsq	$-6640827866535438581, %rdx
	movq	%rcx, %rax
	imulq	%rdx
	leaq	(%rdx,%rcx), %rax
	sarq	$6, %rax
	movq	%rax, %rdx
	movq	%rcx, %rax
	sarq	$63, %rax
	subq	%rax, %rdx
	movl	-36(%rbp), %eax
	cltq
	movl	-20(%rbp,%rax,4), %eax
	movq	%rdi, %r8
	movq	%rsi, %rcx
	movl	%eax, %esi
	leaq	.LC0(%rip), %rax
	movq	%rax, %rdi
	movl	$0, %eax
	call	printf@PLT
	addl	$1, -36(%rbp)
.L6:
	cmpl	$2, -36(%rbp)
	jle	.L7
	movl	$0, %eax
	movq	-8(%rbp), %rdx
	subq	%fs:40, %rdx
	je	.L9
	call	__stack_chk_fail@PLT
.L9:
	leave
	.cfi_def_cfa 7, 8
	ret
	.cfi_endproc
.LFE1:
	.size	main, .-main
	.ident	"GCC: (Ubuntu 13.3.0-6ubuntu2~24.04.1) 13.3.0"
	.section	.note.GNU-stack,"",@progbits
	.section	.note.gnu.property,"a"
	.align 8
	.long	1f - 0f
	.long	4f - 1f
	.long	5
0:
	.string	"GNU"
1:
	.align 8
	.long	0xc0000002
	.long	3f - 2f
2:
	.long	0x3
3:
	.align 8
4:
